package com.wallet.yukoni;

import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextPaint;
import android.widget.TextView;

public class DashBoardActivity extends AppCompatActivity {
 TextView titletext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);

        titletext = findViewById(R.id.title_textview);

        titletext.setText("Tianjin, China".toUpperCase());

        TextPaint paint = titletext.getPaint();
        float width = paint.measureText("Yukoni");

        Shader textShader = new LinearGradient(0, 0, width, titletext.getTextSize(),
                new int[]{
                        Color.parseColor("#F97C3C"),
                        Color.parseColor("#FDB54E"),
                        Color.parseColor("#64B678"),
                        Color.parseColor("#478AEA"),
                        Color.parseColor("#8446CC"),
                }, null, Shader.TileMode.CLAMP);
        titletext.getPaint().setShader(textShader);
    }
}
